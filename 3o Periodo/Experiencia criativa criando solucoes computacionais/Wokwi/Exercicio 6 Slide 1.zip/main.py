from machine import Pin
from time import sleep

numeros = [
    [0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 1, 1, 1, 1],
    [0, 0, 1, 0, 0, 1, 0],
    [0, 0, 0, 0, 1, 1, 0],
    [1, 0, 0, 1, 1, 0, 0],
    [0, 1, 0, 0, 1, 0, 0],
    [0, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 1, 0, 0],
    [0, 0, 0, 1, 0, 0, 0],
    [1, 1, 0, 0, 0, 0, 0],
    [0, 1, 1, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 1, 0],
    [0, 1, 1, 0, 0, 0, 0],
    [0, 1, 1, 1, 0, 0, 0]
]
display = [
    Pin(13, Pin.OUT),
    Pin(12, Pin.OUT),
    Pin(14, Pin.OUT),    
    Pin(27, Pin.OUT),
    Pin(26, Pin.OUT),
    Pin(25, Pin.OUT),
    Pin(33, Pin.OUT)
    ]
chaveprincipal = Pin(18, Pin.PULL_UP)
chave1 = Pin(23, Pin.PULL_UP)
chave2 = Pin(22, Pin.PULL_UP)
chave3 = Pin(21, Pin.PULL_UP)
chave4 = Pin(19, Pin.PULL_UP)

while True:
    sleep(1)
    if chaveprincipal.value() == 1:
        print("Display travado!")
    else:
        binario = (f"{chave1.value()}{chave2.value()}{chave3.value()}{chave4.value()}")
        decimal = int(binario, 2)
        print(decimal)
        for j in range(len(display)):
            display[j].value(numeros[decimal][j])