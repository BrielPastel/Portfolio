import machine
from machine import PWM
import time

#Aqui é o exemplo de como usar o PULL_UP
chaveprinc1 = machine.Pin(26,machine.Pin.IN)
chaveprinc2 = machine.Pin(25,machine.Pin.IN)
chave1 = machine.Pin(13,machine.Pin.IN)
chave2 = machine.Pin(12,machine.Pin.IN)
chave3 = machine.Pin(14,machine.Pin.IN)
chave4 = machine.Pin(27,machine.Pin.IN)
buzzer = PWM(machine.Pin(15))



while True:
    
    if chaveprinc1.value() == 0 and chaveprinc2.value() == 0 and chave1.value() == 1 :
        buzzer.freq(100)
        buzzer.duty(512)

    elif chaveprinc1.value() == 0 and chaveprinc2.value() == 1 and chave2.value() == 1 :
        buzzer.freq(200)
        buzzer.duty(512)

    elif chaveprinc1.value() == 1 and chaveprinc2.value() == 0 and chave3.value() == 1 :
        buzzer.freq(300)
        buzzer.duty(512)

    elif chaveprinc1.value() == 1 and chaveprinc2.value() == 1 and chave4.value() == 1 :
        buzzer.freq(400)
        buzzer.duty(512)

    else:
        buzzer.duty(0)
        print("sem sinal!")

    time.sleep(1)