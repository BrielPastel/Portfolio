print("Hello WOKWI!")
from machine import Pin
import machine
import dht
import time

def verificarhum(hum):
    if hum > 50:
        print("Há vazamento!")
        
def verificartemp(temp):
    if temp > 30 and temp <= 50:
        print("Motor de resfriamento está estragado!")

def verificarfogo(temp):
    if temp > 50:
        print("ALERTA, pode haver fogo no local!!")
        return True
    else:
        return False

chave = Pin(13, Pin.IN)
led = Pin(2, Pin.OUT)
sensor = dht.DHT22(machine.Pin(2))

while True:
    time.sleep(3)
    sensor.measure()
    if verificarfogo(sensor.temperature()):
        led.on()
    else:
        led.off()
    if chave.value() == 1:
        verificarhum(sensor.humidity())
        verificartemp(sensor.temperature())